Progress
========

This module provides an interface to track the progress of computations.

Copyright (c) 2015-2016 Thomas Mertz

Author : Thomas Mertz
Webpage: www.thomasmertz.eu
Email  : mertz.itp.uni-frankfurt@outlook.com

Below you can find a manual for installation.


Installation:
=============

Admin:

python setup.py install

If you don't have administrator priviledges on your system:

python setup.py install --user



Documentation:
==============

To create an HTML documentation type

python -m pydoc -w Progress
